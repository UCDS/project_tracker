<?php if(preg_match("^".base_url()."reports^",current_url()) || preg_match("^".base_url()."masters^",current_url()) || preg_match("^".base_url()."projects^",current_url())){ ?>
</div>
<?php } ?>
</div>
<!-- End container -->
</div>
<!-- End Wrap -->

<div id="footer">
      <div class="container">
        <p class="text-muted">
		a Free and Open Source Application supported by <a href="http://www.yousee.in" target="_blank">YouSee</a>
		</p>
      </div>
</div>
</body>
</html>